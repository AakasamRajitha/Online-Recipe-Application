async function register() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const email = document.getElementById('email').value;

    const response = await fetch('http://localhost:8080/api/login/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            username: username,
            password: password,
            email: email,
        }),
    });

    const resultDiv = document.getElementById('result');

    if (response.ok) {
        resultDiv.innerHTML = 'User registered successfully!';
    } else {
        const data = await response.json();
        resultDiv.innerHTML = `Error: ${data.message}`;
    }
}
