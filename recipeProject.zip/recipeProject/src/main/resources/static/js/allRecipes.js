// src/main/resources/static/js/allRecipes.js

async function getRecipes() {
    try {
        const response = await fetch('/recipes/allRecipes');

        if (response.ok) {
            const recipes = await response.json();
            document.getElementById('recipeList').innerHTML = JSON.stringify(recipes);
        } else {
            const errorData = await response.json();
            alert(`Error: ${errorData.message}`);
        }
    } catch (error) {
        console.error('Error getting recipes:', error);
    }
}
