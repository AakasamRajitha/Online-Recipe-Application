// src/main/resources/static/js/deleteRecipe.js

document.getElementById('deleteRecipeForm').addEventListener('submit', async function (event) {
    event.preventDefault();

    const recipeId = document.getElementById('recipeId').value;

    try {
        const response = await fetch(`/recipes/deleteMapping/${recipeId}`, {
            method: 'DELETE',
        });

        if (response.ok) {
            alert('Recipe deleted successfully!');
        } else {
            const errorData = await response.json();
            alert(`Error: ${errorData.message}`);
        }
    } catch (error) {
        console.error('Error deleting recipe:', error);
    }
});
