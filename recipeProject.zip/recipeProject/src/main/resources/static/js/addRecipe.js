// src/main/resources/static/js/addRecipe.js

document.getElementById('addRecipeForm').addEventListener('submit', async function (event) {
    event.preventDefault();

    const name = document.getElementById('name').value;
    const servings = document.getElementById('servings').value; // Add other form fields as needed
    const instructions = document.getElementById('instructions').value;
    const veg = document.getElementById('veg').checked;

    const data = {
        name: name,
        servings: servings,
        instructions: instructions,
        veg: veg,
    };

    try {
        const response = await fetch('/recipes/addRecipe', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        });

        if (response.ok) {
            alert('Recipe added successfully!');
        } else {
            const errorData = await response.json();
            alert(`Error: ${errorData.message}`);
        }
    } catch (error) {
        console.error('Error adding recipe:', error);
    }
});
