// src/main/resources/static/js/updateRecipe.js

document.getElementById('updateRecipeForm').addEventListener('submit', async function (event) {
    event.preventDefault();

    const recipeId = document.getElementById('recipeId').value;
    const name = document.getElementById('name').value; // Add other form fields for updating
    const servings = document.getElementById('servings').value;
    const instructions = document.getElementById('instructions').value;
    const veg = document.getElementById('veg').checked;

    const data = {
        name: name,
        servings: servings,
        instructions: instructions,
        veg: veg,
    };

    try {
        const response = await fetch(`/recipes/updateRecipe/${recipeId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        });

        if (response.ok) {
            alert('Recipe updated successfully!');
        } else {
            const errorData = await response.json();
            alert(`Error: ${errorData.message}`);
        }
    } catch (error) {
        console.error('Error updating recipe:', error);
    }
});
