package anu.com.recipes.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table(name="INGREDIENTS")
public class Ingredients 
{
  @Id
  @GeneratedValue(strategy=GenerationType.IDENTITY)
  
  private int id;
  
  @Column
  private String ingredientList;
  
  public Ingredients()
  {
	  super();
  }
  
  public Ingredients(int id, String ingredientList) 
  {
	super();
	this.id = id;
	this.ingredientList = ingredientList;
  }
  

  public int getId() 
  {
	return id;
  }

  public void setId(int id)
  {
	this.id = id;
  }

  public String getIngredientList() 
  {
	return ingredientList;
  }

  public void setIngredientList(String ingredientList)
  {
	this.ingredientList = ingredientList;
  }

  
}
