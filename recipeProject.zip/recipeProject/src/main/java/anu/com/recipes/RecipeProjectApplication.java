package anu.com.recipes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;



@SpringBootApplication
@ComponentScan(basePackages = "anu.com.recipes")
public class RecipeProjectApplication
{

	public static void main(String[] args) 
	{
		SpringApplication.run(RecipeProjectApplication.class, args);
		System.out.println("welcome to online recipe application");	
	}

}
