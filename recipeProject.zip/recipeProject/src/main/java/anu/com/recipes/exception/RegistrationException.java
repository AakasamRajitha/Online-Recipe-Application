package anu.com.recipes.exception;

public class RegistrationException extends RuntimeException
{
	  public RegistrationException(String message)
	    {
	        super(message);
	    }
	

}
