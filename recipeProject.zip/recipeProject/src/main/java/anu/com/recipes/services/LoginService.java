package anu.com.recipes.services;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import anu.com.recipes.entity.LoginEntity;
import anu.com.recipes.exception.RegistrationException;
import anu.com.recipes.repository.LoginRepository;
import jakarta.transaction.Transactional;

@Service

public class LoginService 
{
	 @Autowired
	    private static LoginRepository loginRepository;
	    public LoginService(LoginRepository loginRepository) {
	        this.loginRepository = loginRepository;
	    }
	    public static void registerUser(String username, String password, String email) throws RegistrationException {
	        
	        if (loginRepository.existsByUsername(username)) {
	            throw new RegistrationException("Username is already taken");
	        }

	        if (loginRepository.existsByEmail(email)) {
	            throw new RegistrationException("Email is already registered");
	        }

	        // Create a new user entity and save it to the database
	        LoginEntity newUser = new LoginEntity();
	        newUser.setUsername(username);
	        newUser.setPassword(password);
	        newUser.setEmail(email);

	        loginRepository.save(newUser);
	    }
}

