package anu.com.recipes.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import anu.com.recipes.entity.LoginEntity;
import anu.com.recipes.exception.RegistrationException;
import anu.com.recipes.services.LoginService;

@Controller
@RequestMapping("/api/login")
public class LoginController {
    
    @GetMapping("/register")
    public String showRegisterPage(Model model) {
       
        return "register";
    }

    @PostMapping("/register")
    public String handleRegistration(@RequestBody LoginEntity request) 
    {
    	try {
            LoginService.registerUser(request.getUsername(), request.getPassword(), request.getEmail());
            return "redirect:/api/login/register";
        } 
    	catch (RegistrationException e) 
    	{ 
            return "redirect:/api/login/register"; 
    	} 
    }
}
