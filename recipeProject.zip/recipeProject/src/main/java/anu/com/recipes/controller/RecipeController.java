package anu.com.recipes.controller;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import anu.com.recipes.entity.Recipe;
import anu.com.recipes.exception.RecipeNotFoundException;
import anu.com.recipes.repository.IRecipeRepository;
import anu.com.recipes.serviceimpl.RecipeServiceImpl;
import anu.com.recipes.services.IRecipeService;

@Controller

@RequestMapping("/recipes")
public class RecipeController 
{
	@GetMapping("/recipesPage")
	public String getRecipesPage() {
	    return "recipesPage"; // This corresponds to recipes.html in src/main/resources/templates
	}

	@Autowired
   private IRecipeService recipeService;
   
   @Autowired
    IRecipeRepository recipeRepository;
   @Autowired
   RecipeServiceImpl recipeServiceImpl;
   

   @GetMapping("/allRecipes")
   public ResponseEntity<List<Recipe>> getAllRecipes() throws RecipeNotFoundException {
       List<Recipe> checkrecipe = recipeService.findAll();
       if (checkrecipe.isEmpty()) {
           throw new RecipeNotFoundException("NO recipe in the list");
       } else {
           return new ResponseEntity<>(checkrecipe, HttpStatus.OK);
       }
   }

   @PostMapping("/addRecipe")
   public ResponseEntity<Recipe>createRecipe(@RequestBody Recipe recipe)throws RecipeNotFoundException
   {
	   Optional<Recipe> opt = 	recipeRepository.findByName(recipe.getName());
	   
	   
	   
		   
		   Recipe newrecipe =recipeService.saveRecipe(recipe);
		   System.out.println("Recipe is added in the list");
		   return new ResponseEntity<>(newrecipe ,HttpStatus.CREATED);
	   
   }
   
   @PutMapping("/UpdateRecipe/{recipeId}")
   public ResponseEntity<Recipe> updateRecipe(@PathVariable int recipeId, @RequestBody Recipe updatedRecipe)
           throws RecipeNotFoundException {
       // Check if the recipe with the given ID exists
       Optional<Recipe> existingRecipeOptional = recipeService.findById(recipeId);
       if (existingRecipeOptional.isEmpty()) {
           throw new RecipeNotFoundException("Recipe with ID " + recipeId + " not found");
       }

       // Update the existing recipe with the new information
       Recipe existingRecipe = existingRecipeOptional.get();
       existingRecipe.setName(updatedRecipe.getName());
       existingRecipe.setCreated(updatedRecipe.getCreated());
       existingRecipe.setVeg(updatedRecipe.isVeg());
       existingRecipe.setServings(updatedRecipe.getServings());
       existingRecipe.setInstructions(updatedRecipe.getInstructions());

       // Save the updated recipe back to the database
       Recipe updatedRecipeEntity = recipeService.updateRecipe(existingRecipe);

       System.out.println("Recipe with ID " + recipeId + " is updated successfully");

       return new ResponseEntity<>(updatedRecipeEntity, HttpStatus.ACCEPTED);
   }

   
   @DeleteMapping("/deleteMapping/{recipeId}")
   public ResponseEntity<String> deleteRecipe(@PathVariable("recipeId")int recipeId)throws RecipeNotFoundException
   {
	   Optional<Recipe> opt = recipeRepository.findById(recipeId);
	   if(opt.isPresent())
	   {
		   recipeService.deleteRecipe(recipeId);
		   return new ResponseEntity<>("RecipeId :"+recipeId+"is deleted successfully",HttpStatus.OK);
	   }
	   else
	   {
		   throw new RecipeNotFoundException("Recipe id :"+recipeId+"is not found");
	   }
   }
   
}
