package anu.com.recipes.exception;

public class LoginException extends RuntimeException 
{
	public LoginException(String message) {
        super(message);
    }
}
